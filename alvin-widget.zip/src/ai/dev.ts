import { config } from 'dotenv';
config();

import '@/ai/flows/answer-hr-questions.ts';
import '@/ai/flows/smart-escalation.ts';
import '@/ai/flows/generate-sample-questions.ts';
