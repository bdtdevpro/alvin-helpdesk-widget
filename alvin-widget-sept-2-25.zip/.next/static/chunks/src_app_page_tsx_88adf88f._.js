(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_intro_js_intro_module_2d18d8c4.js",
  "static/chunks/src_c064725b._.js",
  "static/chunks/node_modules_next_f601dcbf._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
  "static/chunks/node_modules_edb81c8c._.js"
],
    source: "dynamic"
});
