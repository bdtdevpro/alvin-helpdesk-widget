module.exports = {

"[project]/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/@opentelemetry/api [external] (@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("@opentelemetry/api", () => require("@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/favicon--route-entry.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET),
    "dynamic": (()=>dynamic)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("AAABAAEAIB4AAAEAIACgDwAAFgAAACgAAAAgAAAAPAAAAAEAIAAAAAAAAA8AAMMOAADDDgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoDMEAKAyAwKhNAUeoDQGV6A1BpOgNQa/oDUG26A1BuigNQbwoDUG76A1BuegNQbUoDUGtqA1Bo2gNAZZoDQFK6AzBQkA//8AoDMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoDEEAJ8qAACgMwYkoDUGgKA1BtCgNQb1oDUG/6A1Bv6gNQbqoDUG96A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/qA1BvegNQbfoDUGr6A0BmmgNQUioDQGAqE0BQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ80BACfMgMGoDQGXaA1BtSgNQb+oDUG/6A1Bv+gNQbtoDUGjaA1BXCgNQbyoDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/KA1BtmgNQZ7oDMEGKI2BQCdMAQAAAAAAAAAAAAAAAAAAAAAAAAAAACfNAUAnzQECqA0BX6gNQbzoDUG/6A1Bv+gNQb/oDUG0aA1BUyeMwQGoDUGkaA1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/6A1Bv2gNQa6nzQGKqE3BwCNHAAAAAAAAAAAAAAAAAAAnzMEAJ8yBAWgNQV6oDUG9qA1Bv+gNQb/oDUG/6A1Br+gNAUtoTUHAKA0BQugNQa+oDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQb/oDUG/6A1Bv+gNQayoDQFFKA0BgAAAAAAAAAAAKEyBACePBAAoDUFVKA1Bu+gNQb/oDUG/6A1Bv+gNQbGnzQGJ580BgCfNAQAnjMCBKA1BYigNQb0oDUG/qA1Bv+gNQb/oDUG/6A1Bv+gNQb9oDUG+aA1BuigNQbUoDUGvaA1BrGgNQbLoDUG+aA1BvmgNQazoDUFOqI3BQCfNAUGoDUFUqA1BpmgNQbdoDUG/6A1Bv+gNQb/oDUG4aA0BTygNQYAoDEDAAAAAACgNAYAnzQFDKA1BT+gNQVpoDUGfKA1BoSgNQaDoDUGeqA1BmOgNQZHoDQFL54zBBifMwUJoDQFBp80BBOgNAaOoDUG/aA1Bv+gNQbCoDMFGKA1BUqgNQbpoDUG/6A1Bv+gNQb/oDUG/6A1Bv2gNAV4ZQAAAJ8xBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnzQFAJ80BSCgNQbYoDUG/6A1BvigNAV5oDQFn6A1Bv2gNQb6oDUG/6A1Bv+gNQb/oDUG26A1BiOgNQYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgNQUAoDUEA6A1Bp+gNQb/oDUG/6A1BtGgNQbQoDUG8KA1BqSgNQbzoDUG/6A1Bv+gNQapnjMDBp80BAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ8zAgCgNQcAoDUGc6A1Bv+gNQb/oDUG7aA1BuygNQb+nzUFe6A1BsqgNQb/oDUG/6A1BoaiNgcAlS0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ8zBACfMQMCoDQFN581BR6fNQYAAAAAAKA1BgCgNQVfoDUG+aA1Bv6gNQbcoDUG7aA1Bv+gNQZ8oDUGtaA1BvygNQb8nzUGcqA1BgAAAAAAAAAAAAAAAAAAAAAAoDQGAKA0BiqgNAVTnzQFBp80BQAAAAAAAAAAAAAAAAAAAAAAoDQFAKA0BSGgNQbVoDUGkZ4vAAGfMwIAoDUGAKA1BVigNQbyoDUG6qA0BZKgNQbXoDUG56A0BVSgNQbKoDUG46A1Bu+gNQZmoDUGAAAAAAAAAAAAAAAAAKA0BACgMgEDoDUGl6A1BuegNAUuoDUGAAAAAAAAAAAAAAAAAAAAAACgNQYAoDUGS6A1BvygNQbIoDQFEqA0BQCgNQYAoDQFXKA1Bu+gNQbLoDUGSaA1Bp6gNQbYoDUGnKA1BvegNQbMoDUG5aA1BmagNQYAAAAAAAAAAAAAAAAAnzQGAJ80Bg6gNQbJoDUG/qA0BVmgNQYAAAAAAAAAAAAAAAAAAAAAAKA2BgCgNAZdoDUG/qA1BsuhNQUboTUFAKA1BgCgNQZsoDUG4aA0BWCgMwUJoDUFPaA1BuGgNQb/oDUG+KA1BqugNQbuoDQFd6A1BgAAAAAAAAAAAAAAAACeMwUAnjMFFKA1BtWgNQbuoDUFXaA1BQAAAAAAAAAAAAAAAAAAAAAAoDUGAKA1BlegNQbloDQFb6A0BRWgNAUAozgMAKA1BoygNQbDnzQEDp80BACdMwICoDUFVKA1BrOgNQWSoDUFq6A1Bv+gNQaToFUmAKAzBAAAAAAAAAAAAKA1BQCgNQQPoDUGyqA1BpmgNAY1oDQGAAAAAAAAAAAAAAAAAAAAAACfNQUAnzUFM6A1BtSfNQVnnjQCBZ8zBACfMwQKoDUGvaA1BaGdNQABnjUAAJ0wAwCcKwEAnzQFDqA1BoigNQb3oDUG/6A1BsGfNAQPoDUFAAAAAAAAAAAAnzUFAJ41BAOgNQaXoDUGrp8zBB+fNAUAAAAAAAAAAAAAAAAAAAAAAJ4zBQCeMwUIoDQGaqA0BTugNAcAoDQFAKA0BTSgNQbmoDUGZ6A1BwAAAAAAAAAAAJ4zBACKHwAAoDUFgKA1Bv+gNQb/oDUG7aA1BTygNQYAnTQDAAAAAAAAAAAAoDQFAJ80BSmfNAVQnzQEBZ80BAAAAAAAAAAAAAAAAAAAAAAAAAAAAKAvBgCgLwYAoC8GAKAzBQCfMwUKoDUGm6A1BtifNQUjnzUFAAAAAAAAAAAAAAAAAKA0BQCgNAUdoDUGw6A1Bv+gNQb/oDUGoqA1BQugNQUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKAzBAChMQABnzQFIKA1BpOgNQbsoDUGZSUAAACfMwQAAAAAAAAAAAAAAAAAnzMFAKE2BgCgNAU0oDUGxqA1Bv+gNQb3oDUGjKA0BR2iLQABoTEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoDIDAKM8CQCgNAQMoDQFMqA1Bn2gNQbXoDUG6qA0Bm+gMwYGoDMGAAAAAAAAAAAAAAAAAAAAAAAAAAAAnjMGAKI2BACgNAUioDUGlKA1BuqgNQb+oDUG1aA1BoqhNQZRoDUFMJ81BhygNQUUoDQFE6A0BRSgNAUZnzQFKJ80BT+gNQZeoDUGi6A1Br+gNQbtoDUG96A1BrmgNQZDnzIEA58zBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ81BQCfNAQGoDUFOqA1Bo6gNQbToDUG9qA1BvmgNQbtoDUG4qA1BtWgNQbRoDUG1KA1Bt6gNQbpoDUG9aA1Bv+gNQb8oDUG4qA1BqegNQVTnzQGEKA1CACfNAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACeMQYAnzEGAqA0BRifNAVBoDUGcaA1BpmgNQa0oDUGyaA1BtOgNQbMoDUGwaA1BrWgNQahoDUGf6A1BU+fNAUknzMDBp80BQCgMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACdLwMAnS4DAZ8yBAygNQaHoDUGrZ80BSygNAUMnzMFCZ0yAwKcMwUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACfNAUAnzQFHqA1BtugNQbEnzMEDp8zBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKA1BgCgNQZRoDUG+qA1BtugNQVSnzQEDJ41BACgMgQDnjIDAp4yBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoDUGAKA0Bj2gNQbGoDUG9qA1BvegNQatnzUGa6A1Bp+gNQZ5nzQGEKA0BgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACiNQYAozMHAZ8zBRSgNAZJoDUGkaA1BtKgNQb6oDUG/6A1BvqgNQVkoDUGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ41AwC0PB4AnzUFMaA1Bt+gNQb/oDUG/6A1BnKgNQYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ40BQCcNAUEoDUGeKA1BuegNQa7oDQFJKA0BQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/AAD//gAAH/gAAA/wAAAH4BAAA+AwAAEAeAAAAP//4AD//+AA///wAf/8cAH4/DAB8PwwAfD8MAHw/DEB8PwhwPD8Y+D4/8Pgf/8H8B/8B/gAAA/8AAA//wAA///wD///+H////gn///4A///+AP///+D////g/8=", 'base64');
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
}
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__a6630747._.js.map